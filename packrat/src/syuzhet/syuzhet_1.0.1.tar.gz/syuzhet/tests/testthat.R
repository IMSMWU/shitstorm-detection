library(testthat)
library(syuzhet)

test_check("syuzhet")
